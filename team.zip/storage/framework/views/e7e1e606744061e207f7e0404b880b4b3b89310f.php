

<?php $__env->startSection('title-page'); ?>
    Vinculos de Asociados |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
    ASOCIADOS - Vinculos Familiares
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vinculos', ['asociado' => $asociado])->html();
} elseif ($_instance->childHasBeenRendered('YyDJlMe')) {
    $componentId = $_instance->getRenderedChildComponentId('YyDJlMe');
    $componentTag = $_instance->getRenderedChildComponentTagName('YyDJlMe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YyDJlMe');
} else {
    $response = \Livewire\Livewire::mount('vinculos', ['asociado' => $asociado]);
    $html = $response->html();
    $_instance->logRenderedChild('YyDJlMe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    Livewire.on('alertSuccess', function(){
        toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    toastr.success("Vinculo agregado correctamente");
    })
    
</script>
<script>
    Livewire.on('alertDanger', function(){
        toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    toastr.error("Vinculo eliminado correctamente");
    })
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\team\resources\views/asociado/vinculos.blade.php ENDPATH**/ ?>