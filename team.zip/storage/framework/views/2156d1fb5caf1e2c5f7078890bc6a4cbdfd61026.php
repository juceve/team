<?php $__env->startSection('template_title'); ?>
    Update User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card card-default">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Asignación de Roles</strong>
                            </span>

                             <div class="float-right">
                                <a href="/users" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                                </a>
                              </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <p><strong>Usuario: </strong></p>
                        <p class="form-control"><?php echo e($user->name); ?></p>
                        
                        
                        <h2 class="h5">Listado de roles</h2>
                        <?php echo Form::model($user, ['route' => ['users.update',$user], 'method' => 'put']); ?>

                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                     <label>
                                        <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1']); ?>

                                        <?php echo e($role->name); ?>

                                     </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo Form::submit('Asignar rol', ['class' => 'btn btn-primary mt-2']); ?>

                        <?php echo Form::close(); ?>

                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('info') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('info')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\devconta\resources\views/user/edit.blade.php ENDPATH**/ ?>