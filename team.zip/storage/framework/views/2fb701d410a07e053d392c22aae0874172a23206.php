<?php $__env->startSection('title-page'); ?>
Listado de Roles  |  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
ROLES REGISTRADOS   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Listado de Roles</strong>
                            </span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.create')): ?>
                                <div class="float-right">
                                <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm float-right"
                                    data-placement="left">
                                    <i class="fas fa-plus-circle"></i>
                                    <?php echo e(__('Crear nuevo')); ?>

                                </a>
                            </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover dataTable">
                                <thead class="thead">
                                    <tr>
                                        <th>ID</th>
                                        
										<th>NOMBRE</th>

                                        <th width="150px"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($role->id); ?></td>
                                            
											<td><?php echo e($role->name); ?></td>

                                            <td class="text-center">
                                                <form action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="POST" class="eliminar">
                                                   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.edit')): ?>
                                                       <a class="btn btn-sm btn-success" href="<?php echo e(route('roles.edit',$role->id)); ?>" title="Editar"><i class="fa fa-fw fa-edit"></i></a>
                                                   <?php endif; ?>
                                                    
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.destroy')): ?>
                                                       <button type="submit" class="btn btn-danger btn-sm" title="Eliminar"><i class="fa fa-fw fa-trash"></i></button> 
                                                    <?php endif; ?>
                                                    
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            $('.eliminar').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Esta seguro de eliminar el registro?',
                    text: "El registro eliminado no se podrá recuperar",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, eliminar!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devconta\resources\views/role/index.blade.php ENDPATH**/ ?>