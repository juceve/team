<?php $__env->startSection('template_title'); ?>
    <?php echo e(Auth::user()->name ?? 'Show User'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title-page'); ?>
    Mi Perfil |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
    Mi Perfil
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Datos del usuario</strong>
                            </span>
                            
                            <div class="float-right">
                                <a href="javascript:history.back();" class="btn btn-primary btn-sm float-right"
                                    data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                            </div>
                            

                        </div>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('asociado.datospersonales', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table">
                            <tr>
                                <td>
                                    <strong>Nombre:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Email:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->email); ?>

                                </td>
                            </tr>
                           
                            <tr>
                                <td>
                                    <strong>Tipo de usuario:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->roles->pluck('name')[0]); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Avatar:</strong>
                                </td>
                                <td>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('uploadpics')->html();
} elseif ($_instance->childHasBeenRendered('24QmYY0')) {
    $componentId = $_instance->getRenderedChildComponentId('24QmYY0');
    $componentTag = $_instance->getRenderedChildComponentTagName('24QmYY0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('24QmYY0');
} else {
    $response = \Livewire\Livewire::mount('uploadpics');
    $html = $response->html();
    $_instance->logRenderedChild('24QmYY0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\team\resources\views//user/show.blade.php ENDPATH**/ ?>