<?php $__env->startSection('template_title'); ?>
    <?php echo e(Auth::user()->name ?? 'Show User'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title-page'); ?>
    Mi Perfil |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
    Mi Perfil
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Datos del usuario</strong>
                            </span>
                            
                            <div class="float-right">
                                <a href="javascript:history.back();" class="btn btn-primary btn-sm float-right"
                                    data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                            </div>
                            

                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <td>
                                    <strong>Name:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->name); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Email:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->email); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Cliente asignado:</strong>
                                </td>
                                <td>
                                    <?php if(!is_null(Auth::user()->cliente_id)): ?>
                                        <?php echo e(Auth::user()->cliente_id); ?>

                                    <?php else: ?>
                                        <span class="text-danger"><i>No asignado</i></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Rol:</strong>
                                </td>
                                <td>
                                    <?php echo e(Auth::user()->roles->pluck('name')[0]); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Avatar:</strong>
                                </td>
                                <td>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('uploadpics')->html();
} elseif ($_instance->childHasBeenRendered('XmtBlNI')) {
    $componentId = $_instance->getRenderedChildComponentId('XmtBlNI');
    $componentTag = $_instance->getRenderedChildComponentTagName('XmtBlNI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XmtBlNI');
} else {
    $response = \Livewire\Livewire::mount('uploadpics');
    $html = $response->html();
    $_instance->logRenderedChild('XmtBlNI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devconta\resources\views//user/show.blade.php ENDPATH**/ ?>