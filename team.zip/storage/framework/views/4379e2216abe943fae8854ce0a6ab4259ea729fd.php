<?php $__env->startSection('title-page'); ?>
Editar Usuario  |  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
EDITAR PARAMETROS DE USUARIO   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card card-default">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Datos de usuario</strong>
                            </span>

                             <div class="float-right">
                                <a href="/users" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                                </a>
                              </div>
                        </div>
                    </div>
                    <?php echo Form::model($user, ['route' => ['users.update',$user], 'method' => 'put']); ?>

                    <div class="card-body">
                        <div class="box box-info padding-1">
                            <div class="box-body">
                                
                                <div class="form-group">
                                    <?php echo e(Form::label('Nombre Usuario:')); ?>

                                    <?php echo e(Form::text('name', $user->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

                                    <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                                <div class="form-group d-none">
                                    <?php echo e(Form::label('email')); ?>

                                    <?php echo e(Form::text('email', $user->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

                                    <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                                <div class="form-group">
                                    <label for="">Asignar cliente:</label>
                                    <?php
                                        $selected = '';
                                    ?>
                                    <select name="cliente_id" id="cliente_id" class="form-control select2">
                                        <option value="0">Seleccione un cliente</option>
                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                if($cliente->id == $user->cliente_id)
                                                {
                                                    $selected = 'selected';
                                                }
                                                else {
                                                    $selected = '';
                                                }

                                                if($cliente->casamatriz != 0)
                                                {
                                                    $cliente->razonsocial = $cliente->namecasa . ' - ' . $cliente->razonsocial;
                                                }
                                            ?>
                                            <option value="<?php echo e($cliente->id); ?>" <?php echo e($selected); ?>><?php echo e($cliente->razonsocial); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    <?php echo $errors->first('cliente_id', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                                 <div class="form-group d-none">
                                    <?php echo e(Form::label('Avatar')); ?>

                                    <?php echo e(Form::text('avatar', $user->avatar, ['class' => 'form-control' . ($errors->has('avatar') ? ' is-invalid' : ''), 'placeholder' => 'Avatar'])); ?>

                                    <?php echo $errors->first('avatar', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                            </div>
                        </div>
                        
                        <hr>
                        <h2 class="h5">Asignación de Roles</h2>
                        
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                     <label>
                                        <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1']); ?>

                                        <?php echo e($role->name); ?>

                                     </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar cambios</button type="submit" class="btn btn-primary">
                        
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(".select2").select2();
</script>
    <?php if(session('info') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('info')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devconta\resources\views/user/edit.blade.php ENDPATH**/ ?>