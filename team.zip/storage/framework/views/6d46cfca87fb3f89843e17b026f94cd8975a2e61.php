<div>
    <form wire:submit.prevent="save">
        <div class="form-group">
            <input class="form-control" type="file" wire:model="photo">
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="error"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <?php if($photo): ?>
                <small>Vista previa:</small><br>
                <img src="<?php echo e($photo->temporaryUrl()); ?>" style="width: 150px;">
                <div class="form-group">
                    <button class="btn btn-primary" type="submit">Actualizar Avatar</button>
                </div>
            <?php endif; ?>
        </div>

    </form>
</div>
<?php /**PATH C:\xampp\htdocs\team\resources\views/livewire/uploadpics.blade.php ENDPATH**/ ?>