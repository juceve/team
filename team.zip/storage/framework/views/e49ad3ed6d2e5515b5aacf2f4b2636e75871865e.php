<!DOCTYPE HTML>
<html class="no-js" lang="de">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="robots" content="index,follow">

    <title>Pro Finance</title>
    <link href="<?php echo e(asset('web/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/bwt.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/full-slider.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('web/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/style.css')); ?>" rel="stylesheet">
    <!-- Custom Fonts -->

    <link href="<?php echo e(asset('web/css/css_font_google.css')); ?>" rel="stylesheet">

    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head>

<body class="header-sticky">

    <div class="boxed">
        <div class="loader">
            <span class="loader1 block-loader"></span>
            <span class="loader2 block-loader"></span>
            <span class="loader3 block-loader"></span>
        </div>

        <div class="header-inner-pages">
            <div class="top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="bwt-information">
                                <li class="phone">
                                    <a href="#" title="Phone number"><i class="fa fa-phone"></i> Call us:
                                        1234567890</a>
                                </li>
                                <li class="email">
                                    <a href="#" title="Email address"><i class="fa fa-envelope"></i> Email:
                                        support24/7@financepro.com</a>
                                </li>
                            </ul>
                        </div><!-- col-md-12 -->
                    </div><!-- row -->
                </div><!-- container -->
            </div><!-- Top -->
        </div><!-- header-inner-pages -->

        <!-- Wrap-slide -->
        <div class="wrap-slider">
            <!-- Header -->
            <header id="header" class="header style-color clearfix">
                <div class="container">
                    <div class="header-wrap clearfix">
                        <div id="logo" class="logo">
                            <a href="index.html" rel="home">
                                <img src="<?php echo e(asset('web/images/logo.png')); ?>" class="img-fluid" alt="Logo">
                            </a>
                        </div><!-- /.logo -->

                        <div class="nav-wrap">
                            <div class="btn-menu">
                                <span></span>
                            </div><!-- //mobile menu button -->

                            <nav id="mainnav" class="mainnav">
                                <ul class="menu">
                                    <li>
                                        <a class="active" href="index.html">Home</a>
                                    </li>
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="services.html">Services</a>
                                    </li>
                                    <li><a href="blog.html">Blog</a>
                                    </li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                    <li>
                                        <?php if(Route::has('login')): ?>
                                                <?php if(auth()->guard()->check()): ?>
                                                    <a href="<?php echo e(url('/home')); ?>"
                                                        class=""><i class="fas fa-file-invoice-dollar"></i><i class="fa fa-desktop" aria-hidden="true"></i> DEVCONTA</a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('login')); ?>"
                                                        class=""><i class="fa fa-sign-in" aria-hidden="true"></i> Ingresar</a>

                                                    
                                                <?php endif; ?>
                                        <?php endif; ?>
                                    </li>
                                </ul><!-- /.menu -->
                            </nav><!-- /.mainnav -->
                        </div><!-- /.nav-wrap -->
                    </div><!-- /.header-wrap -->
                </div>
            </header><!-- /.header -->
        </div> <!-- /.wrap-slider -->

        <section>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <!-- Slide One - Set the background image for this slide in the line below -->
                    <div class="carousel-item active"
                        style="background-image: url('<?php echo e(asset('web/images/slide-1.jpg')); ?>')">
                        <div class="carousel-caption d-md-block">
                            <h3>Lorem ipsum dolor sit amet</h3>
                            <p>Donec rutrum congue leo eget malesuada.</p>
                            <a href="#" class="btn">Know More</a>
                        </div>
                    </div>
                    <!-- Slide Two - Set the background image for this slide in the line below -->
                    <div class="carousel-item"
                        style="background-image: url('<?php echo e(asset('web/images/slide-2.jpg')); ?>')">
                        <div class="carousel-caption d-md-block">
                            <h3>Lorem ipsum dolor sit amet</h3>
                            <p>Donec rutrum congue leo eget malesuada.</p>
                            <a href="#" class="btn">Know More</a>
                        </div>
                    </div>
                    <!-- Slide Three - Set the background image for this slide in the line below -->
                    <div class="carousel-item"
                        style="background-image: url('<?php echo e(asset('web/images/slide-3.jpg')); ?>')">
                        <div class="carousel-caption d-md-block">
                            <h3>Lorem ipsum dolor sit amet</h3>
                            <p>Donec rutrum congue leo eget malesuada.</p>
                            <a href="#" class="btn">Know More</a>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </section>
        <section class="bwt-service bwt-top-90">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-4 box1">
                        <div class="thumb">
                            <img src="<?php echo e(asset('web/images/service-1.jpg')); ?>" alt="image">
                            <div class="overlay"></div>
                        </div>
                        <div class="box-header">
                            <i class="fa fa-cubes icon" aria-hidden="true"></i>
                        </div>
                        <div class="box-post">
                            <div class="box-title">
                                <h4 class="title">Lorem Ipsum was popularised</h4>
                                <div class="box-content">
                                    <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque
                                        laudantium, totam aperiam.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-4 box2">
                        <div class="thumb">
                            <img src="<?php echo e(asset('web/images/service-2.jpg')); ?>" alt="image">
                            <div class="overlay"></div>
                        </div>
                        <div class="box-header v1">
                            <i class="fa fa-money icon" aria-hidden="true"></i>

                        </div>
                        <div class="box-post">
                            <div class="box-title">
                                <h4 class="title">Lorem Ipsum was popularised </h4>
                                <div class="box-content">
                                    <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque
                                        laudantium, totam aperiam.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-4 box3">
                        <div class="thumb">
                            <img src="<?php echo e(asset('web/images/service-3.jpg')); ?>" alt="image">
                            <div class="overlay"></div>
                        </div>
                        <div class="box-header v2">
                            <i class="fa fa-globe icon" aria-hidden="true"></i>

                        </div>
                        <div class="box-post">
                            <div class="box-title">
                                <h4 class="title">Lorem Ipsum was popularised</h4>
                                <div class="box-content">
                                    <p>Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque
                                        laudantium, totam aperiam.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bwt-service-info bwt-top-30">
            <div class=" container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-4 box1">
                        <div class="num">
                            <p>15+</p>
                        </div>
                        <div class="text">
                            <h4 class="title">Global <br>Locations</h4>
                            <a href="#" class="comment-reply">Find Our Location <i
                                    class="fa fa-chevron-right"></i></a>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-4 box2">
                        <div class="num">
                            <p>+1k</p>
                        </div>
                        <div class="text">
                            <h4 class="title">Successful <br>Project</h4>
                            <a href="#" class="comment-reply">View All <i class="fa fa-chevron-right"></i></a>
                        </div>
                    </div>

                    <div class="col-sm-12 col-md-12 col-lg-4 box3">
                        <div class="num">
                            <p>10+</p>
                        </div>
                        <div class="text">
                            <h4 class="title">Years of <br>Experience</h4>
                            <a href="#" class="comment-reply">Learn More <i
                                    class="fa fa-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="bwt-top-0">
            <div class="bwt-clients">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="thumb-clients v1">
                                <img src="<?php echo e(asset('web/images/clients/1.png')); ?>" alt="image">
                            </div>
                            <div class="thumb-clients v2">
                                <img src="<?php echo e(asset('web/images/clients/2.png')); ?>" alt="image">
                            </div>
                            <div class="thumb-clients v3">
                                <img src="<?php echo e(asset('web/images/clients/3.png')); ?>" alt="image">
                            </div>
                            <div class="thumb-clients v4">
                                <img src="<?php echo e(asset('web/images/clients/4.png')); ?>" alt="image">
                            </div>
                            <div class="thumb-clients v5">
                                <img src="<?php echo e(asset('web/images/clients/5.png')); ?>" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="bwt-news bwt-90">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-4">
                        <div class="box">
                            <div class="title-v1">
                                <h4 class="title">Request Call Back.</h4>
                                <p>Lorem Ipsum was popularised in the with the release of Letraset sheets contai ningthe
                                </p>
                            </div>
                            <div class="form-box">
                                <form action="#" method="post" id="commentform-footer" class="comment-form"
                                    novalidate>
                                    <select name="style cars">
                                        <option value="1" selected="">How can we help?</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>

                                    <div class="style name-container">
                                        <input id="author-footer" placeholder="You name*" class="tb-my-input"
                                            name="author" tabindex="1" value="" size="32"
                                            aria-required="true" type="text">
                                    </div>

                                    <div class="style phone-container">
                                        <input id="phone-footer" placeholder="You phone number*" class="tb-my-input"
                                            name="phone" tabindex="2" value="" size="32"
                                            aria-required="true" type="text">
                                    </div>

                                    <div class="style email-container">
                                        <input id="email-footer" placeholder="You Email" class="tb-my-input"
                                            name="email" tabindex="2" value="" size="32"
                                            aria-required="true" type="text">
                                    </div>

                                    <div class="submit-wrap">
                                        <button class=" button-style">submit <i
                                                class="fa fa-chevron-right"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 col-lg-8 md-top-30">
                        <div class="company-news">
                            <div class="title-section">
                                <h4 class="title col-md-12">Latest Blog Posts</h4>
                            </div>
                            <div class="news-section bwt-bottom-20">
                                <div class="col-md-6 left">
                                    <div class="thumb">
                                        <img src="<?php echo e(asset('web/images/blog-1.jpg')); ?>" alt="image">
                                        <div class="overlay"></div>
                                    </div>
                                    <div class="post-1">
                                        <div class="meta-post">
                                            <a href="#">15 November 2016</a>
                                        </div>
                                        <h4 class="title"><a href="#">Nulla quis lorem ut libero malesuada
                                                feugiat.</a></h4>
                                    </div>
                                </div>

                                <div class="col-md-6 left">
                                    <div class="thumb">
                                        <img src="<?php echo e(asset('web/images/blog-2.jpg')); ?>" alt="image">
                                        <div class="overlay"></div>
                                    </div>
                                    <div class="post-1">
                                        <div class="meta-post">
                                            <a href="#">15 November 2016</a>
                                        </div>
                                        <h4 class="title"><a href="#">Nulla quis lorem ut libero malesuada
                                                feugiat.</a></h4>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="post-list col-md-12">
                                <ul class="list-us">
                                    <li>
                                        <div class="num-list">
                                            <p>1</p>
                                        </div>
                                        <div class="text-list">
                                            <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="num-list">
                                            <p>2</p>
                                        </div>
                                        <div class="text-list">
                                            <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                                            </p>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="num-list v3">
                                            <p>3</p>
                                        </div>
                                        <div class="text-list">
                                            <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-4">
                        <div class="footer-logo">
                            <img src="<?php echo e(asset('web/images/logo-2.png')); ?>" class="img-fluid" alt="logo">
                            <div class="im-map">
                                <h5 class="title">Over 20 years of experience</h5>
                                <p>Pellentesque in ipsum id orci porta dapibus. Curabitur arcu erat, accumsan id
                                    imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Donec rutrum congue leo
                                    eget malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non
                                    nisi.</p>
                            </div>
                        </div><!-- footer-logo -->
                    </div><!-- col-md-4 -->


                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="bwt-widget bwt-widget-our-services">
                            <div class="title-link box3">
                                <h5 class="bwt-widget-title">Main Menu</h5>
                            </div>
                            <ul class="our_services">
                                <li class="facebook"><a href="index.html"> Home</a></li>
                                <li class="twitch"><a href="about.html"> About</a></li>
                                <li class="google"><a href="service.html"> Service</a></li>
                                <li class="linkedIn"><a href="news.html"> News</a></li>
                                <li class="youtube"><a href="contact.html"> Contact</a></li>
                            </ul>
                        </div>
                    </div><!-- col-md-3 -->

                    <div class="col-sm-12 col-md-6 col-lg-2">
                        <div class="bwt-widget bwt-widget-follow-us">
                            <div class="title-link box2">
                                <h5 class="bwt-widget-title">Follow Us</h5>
                            </div>
                            <ul class="bwt-follow-us">
                                <li class="facebook"><a href="#"> Facebook</a></li>
                                <li class="twiter"><a href="#"> Twiiter</a></li>
                                <li class="google"><a href="#"> Google Plus </a></li>
                                <li class="linkedIn"><a href="#"> LinkedIn</a></li>
                                <li class="youtube"><a href="#"> Youtube</a></li>
                            </ul>
                        </div>
                    </div><!-- col-md-2 -->


                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="bwt-widget bwt-widget-subscribe-us">
                            <div class="title-link box4">
                                <h5 class="bwt-widget-title">Subscribe Us</h5>
                            </div>
                            <p>Sign Up for our mailing list to get latest updates and news.</p>
                            <div class="bwt-widget subscribe-search">
                                <form action="#" id="mailform" method="get">
                                    <div>
                                        <input type="text" id="ss" class="ssss"
                                            placeholder="Enter your email.">
                                        <button class="submit-button"><i class="fa fa-envelope-open-o"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><!-- row -->
            </div><!-- container -->
        </div><!-- footer -->

        <!-- Bottom -->
        <div class="bwt-footer-copyright">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6 copyright">
                        <div class="left-text">Copyright &copy; Pro Finance 2017. All Rights Reserved</div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Go Top -->
        <a class="go-top">
            <i class="fa fa-arrow-up" aria-hidden="true"></i>
        </a>

        <!-- Javascript -->
        <!-- Javascript -->
        <script type="text/javascript" src="<?php echo e(asset('web/js/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('web/js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('web/js/popper.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('web/js/jquery.easing.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('web/js/main.js')); ?>"></script>
    </div>
</body>

</html>
<?php /**PATH C:\www\devconta\resources\views/welcome.blade.php ENDPATH**/ ?>