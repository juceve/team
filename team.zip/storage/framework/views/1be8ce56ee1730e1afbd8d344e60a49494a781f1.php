<div class="row">
    <div class="col-12 col-md-3 text-center border ">
        <div class="container mt-3 mb-3">
            <h6>IMAGEN DE PERFIL</h6>
            <img src="<?php echo e(Storage::url($asociado->user->avatar)); ?>" class="img-fluid">
            
        </div>


    </div>
    <div class="col-12 col-md-9 border">
        <div class="row form-group">
            <div class="col-12 col-md-6 border ">
                <div class="form-group mt-3">
                    <strong>Nombres:</strong>
                    <?php echo e($persona->nombres); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Apellidos:</strong>
                    <?php echo e($persona->apellidos); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Cedula:</strong>
                    <?php echo e($persona->cedula); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Direccion:</strong>
                    <?php echo e($persona->direccion); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Telefono:</strong>
                    <?php echo e($persona->telefono); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Celular:</strong>
                    <?php echo e($persona->celular); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Correo electrónico:</strong>
                    <?php echo e($persona->email); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Fecha de nacimiento:</strong>
                    <?php echo e($persona->fecnacimiento); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Fecha de ingreso:</strong>
                    <?php echo e($asociado->fecingreso); ?>

                </div>
            </div>
            <div class="col-12 col-md-6 border">
                <div class="form-group mt-3">
                    <strong>Grado:</strong>
                    <?php echo e($asociado->grado->nombre); ?>

                </div>
            </div>
            <div class="col-12 ">
                <div class="form-group mt-3">
                    <strong>Ocupación:</strong>
                    <?php echo e($persona->ocupacion); ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\team\resources\views/asociado/datospersonales.blade.php ENDPATH**/ ?>