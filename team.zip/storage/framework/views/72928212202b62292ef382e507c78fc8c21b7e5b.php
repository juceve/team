<?php $__env->startSection('title-page'); ?>
    Grados |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
    GRADOS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Grados de asociados')); ?>

                            </span>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('grados.create')): ?>
                                <div class="float-right">
                                    <a href="<?php echo e(route('grados.create')); ?>" class="btn btn-primary btn-sm float-right"
                                        data-placement="left">
                                        <i class="fas fa-plus"></i> <?php echo e(__('Nuevo')); ?>

                                    </a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>


                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover dataTable">
                                <thead class="thead">
                                    <tr class="table-info">
                                        <th>NRO</th>

                                        <th>NOMBRE</th>
                                        <th>DESCRIPCIÓN</th>
                                        <th>PAGO ÚNICO</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>

                                            <td><?php echo e($grado->nombre); ?></td>
                                            <td><?php echo e($grado->descripcion); ?></td>
                                            <td><?php echo e($grado->coste); ?></td>

                                            <td align="center">
                                                <form action="<?php echo e(route('grados.destroy', $grado->id)); ?>" method="POST">

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('grados.edit')): ?>
                                                        <a class="btn btn-sm btn-success"
                                                            href="<?php echo e(route('grados.edit', $grado->id)); ?>"><i
                                                                class="fa fa-fw fa-edit"></i> Editar</a>
                                                    <?php endif; ?>


                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('grados.destroy')): ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                                class="fa fa-fw fa-trash"></i> Eliminar</button>
                                                    <?php endif; ?>

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\team\resources\views/grado/index.blade.php ENDPATH**/ ?>