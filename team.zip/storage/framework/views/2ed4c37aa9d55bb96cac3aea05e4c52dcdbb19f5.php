<?php $__env->startSection('template_title'); ?>
    <?php echo e($cliente->name ?? 'Show Cliente'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-success">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php if($cliente->sucursal == 0): ?>
                                    <strong>DATOS DEL CLIENTE</strong>
                                <?php else: ?>
                                    <strong>DATOS DE LA SUCURSAL</strong>
                                <?php endif; ?>

                            </span>

                            <div class="float-right">
                                <a href="/clientes" class="btn btn-primary btn-sm float-right" data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td width="50%"><strong>Razón social:</strong>
                                            <?php echo e($cliente->razonsocial); ?></td>
                                        <td width="50%"><strong>Nit:</strong>
                                            <?php echo e($cliente->nit); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Departamento:</strong>
                                            <?php echo e($cliente->departamento); ?></td>
                                        <td><strong>Ciudad:</strong>
                                            <?php echo e($cliente->ciudad); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Dirección:</strong>
                                            <?php echo e($cliente->direccion); ?></td>
                                        <td><strong>Teléfono:</strong>
                                            <?php echo e($cliente->telefono); ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><strong>Actividad:</strong>
                                            <?php echo e($cliente->actividad); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Responsable:</strong>
                                            <?php echo e($cliente->responsable); ?></td>
                                        <td><strong>Cedula del Responsable:</strong>
                                            <?php echo e($cliente->nrocedularesp); ?></td>
                                    </tr>
                                    <tr>
                                        <?php if($cliente->sucursal == 0): ?>
                                            <td><strong>Sucursal:</strong> CASA MATRIZ
                                            </td>
                                        <?php else: ?>
                                            <td><strong>Sucursal:</strong>
                                                <?php echo e($cliente->sucursal); ?>

                                            </td>
                                        <?php endif; ?>

                                        <?php if($cliente->casamatriz > 0): ?>
                                            <td>
                                                <strong>Casa matriz:</strong>
                                                <a href="../clientes/<?php echo e($idcasamatriz); ?>"
                                                    title="Ver datos Casa Matriz"><?php echo e($casamatriz); ?></a>
                                            </td>
                                        <?php endif; ?>

                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if($cliente->casamatriz == 0): ?>
        <section class="content container-fluid">
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span id="card_title">
                            <strong>SUCURSALES VINCULADAS</strong>
                        </span>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.create')): ?>
                            <div class="float-right">
                                <a href="../createsuc/<?php echo e($cliente->id); ?>" class="btn btn-info btn-sm float-right"
                                    data-placement="left">
                                    <i class="fas fa-plus-circle"></i> Crear nuevo</a>
                                </a>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="card-body table-responsive">
                    <?php if(count($sucursales) > 0): ?>
                        <table class="table table-bordered table-hover dataTable ">
                            <thead>
                                <tr class="table-success text-center">
                                    <th width="100">NRO. SUC.</th>
                                    <th>NOMBRE</th>
                                    <th>CIUDAD</th>
                                    <th width="120"></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($sucursal->sucursal); ?></td>
                                        <td><?php echo e($sucursal->razonsocial); ?></td>
                                        <td><?php echo e($sucursal->ciudad); ?></td>
                                        <td class="text-center">
                                            <form action="<?php echo e(route('clientes.destroy', $sucursal->id)); ?>" method="POST"
                                                class="eliminar">
                                                <a class="btn btn-sm btn-primary "
                                                    href="<?php echo e(route('clientes.show', $sucursal->id)); ?>" title="Ver info"><i
                                                        class="fa fa-fw fa-eye"></i></a>
                                                <a class="btn btn-sm btn-success"
                                                    href="<?php echo e(route('clientes.edit', $sucursal->id)); ?>"
                                                    title="Editar datos"><i class="fa fa-fw fa-edit"></i></a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" title="Eliminar">
                                                    <i class="fa fa-fw fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <span>No cuenta con sucursales registradas.</span>
                    <?php endif; ?>
                </div>

            </div>
        </section>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
    <script>
        $('.dataTables_length').hide()
    </script>

    <script>
        $(document).ready(function() {
            $('.eliminar').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Esta seguro de eliminar el registro?',
                    text: "El registro eliminado no se podrá recuperar",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, eliminar!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\devconta\resources\views/cliente/show.blade.php ENDPATH**/ ?>