<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <h5 class="mt-2">Nombre</h5>
            <?php echo e(Form::text('name', $role->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese el nombre del rol'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <h5 class="mt-2">Listado de persmisos</h5>

        

        <?php
                                        $grupo = '';
                                        $indice = 0;
                                    ?>
                                    <div class="row">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($grupo != $permission->grupo): ?>
                                                <?php
                                                    $grupo = $permission->grupo;
                                                ?>
                                                <?php if($indice > 0): ?>
                                                    </tbody>
                                                    </table>
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-12 col-md-3">
                                        <table class="table table-sm table-bordered">
                                            <thead>
                                                <tr class="table-warning">
                                                    <th>
                                                        <strong><?php echo e($permission->grupo); ?></strong>

                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <label>
                                                            <?php echo Form::checkbox(
                                                                'permissions[]',
                                                                $permission->id,
                                                                null,
                                                                ['class' => 'mr-1'],
                                                            ); ?>

                                                            <?php echo e($permission->description); ?>

                                                        </label>
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td>
                                                        <label>
                                                            <?php echo Form::checkbox(
                                                                'permissions[]',
                                                                $permission->id,
                                                                null,
                                                                ['class' => 'mr-1'],
                                                            ); ?>

                                                            <?php echo e($permission->description); ?>

                                                        </label>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php
                                                    $indice++;
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\devconta\resources\views/role/form.blade.php ENDPATH**/ ?>