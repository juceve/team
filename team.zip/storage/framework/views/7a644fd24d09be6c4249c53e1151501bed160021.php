

<?php $__env->startSection('title-page'); ?>
Example Page  |  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
Example Page    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card-title">
    Titulo de contenido
</div>
<div class="content">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('uploadpics')->html();
} elseif ($_instance->childHasBeenRendered('LwE3TA9')) {
    $componentId = $_instance->getRenderedChildComponentId('LwE3TA9');
    $componentTag = $_instance->getRenderedChildComponentTagName('LwE3TA9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LwE3TA9');
} else {
    $response = \Livewire\Livewire::mount('uploadpics');
    $html = $response->html();
    $_instance->logRenderedChild('LwE3TA9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devconta\resources\views/example.blade.php ENDPATH**/ ?>