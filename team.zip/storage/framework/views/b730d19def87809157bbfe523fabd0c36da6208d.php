<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row form-group">
            <h5>Datos personales</h5>
            <hr>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('nombres')); ?>

                    <?php echo e(Form::text('nombres', $persona->nombres, ['class' => 'form-control' . ($errors->has('nombres') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('nombres', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('apellidos')); ?>

                    <?php echo e(Form::text('apellidos', $persona->apellidos, ['class' => 'form-control' . ($errors->has('apellidos') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('apellidos', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('cédula')); ?>

                    <?php echo e(Form::text('cedula', $persona->cedula, ['class' => 'form-control' . ($errors->has('cedula') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('cedula', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('dirección')); ?>

                    <?php echo e(Form::text('direccion', $persona->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('teléfono')); ?>

                    <?php echo e(Form::text('telefono', $persona->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('celular')); ?>

                    <?php echo e(Form::text('celular', $persona->celular, ['class' => 'form-control' . ($errors->has('celular') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('celular', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Correo electrónico')); ?>

                    <?php echo e(Form::text('email', $persona->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Fecha nacimiento')); ?>

                    <?php echo e(Form::date('fecnacimiento', $persona->fecnacimiento, ['class' => 'form-control' . ($errors->has('fecnacimiento') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('fecnacimiento', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <?php echo e(Form::label('ocupación')); ?>

                    <?php echo e(Form::text('ocupacion', $persona->ocupacion, ['class' => 'form-control' . ($errors->has('ocupacion') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('ocupacion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>


    </div>

</div>
<?php /**PATH C:\xampp\htdocs\team\resources\views/persona/form.blade.php ENDPATH**/ ?>