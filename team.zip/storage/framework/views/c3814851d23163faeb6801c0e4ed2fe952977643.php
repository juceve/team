<div class="box box-info padding-1">
    <div class="box-body">
        <div class="row form-group">
            <h5>Datos personales</h5>
            <hr>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('nombres')); ?>

                    <?php echo e(Form::text('nombres', $persona->nombres, ['class' => 'form-control' . ($errors->has('nombres') ? ' is-invalid' : ''), 'required' => ''])); ?>

                    <?php echo $errors->first('nombres', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('apellidos')); ?>

                    <?php echo e(Form::text('apellidos', $persona->apellidos, ['class' => 'form-control' . ($errors->has('apellidos') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('apellidos', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('cédula')); ?>

                    <?php echo e(Form::text('cedula', $persona->cedula, ['class' => 'form-control' . ($errors->has('cedula') ? ' is-invalid' : ''), 'required' => ''])); ?>

                    <?php echo $errors->first('cedula', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('dirección')); ?>

                    <?php echo e(Form::text('direccion', $persona->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'required' => ''])); ?>

                    <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('teléfono')); ?>

                    <?php echo e(Form::text('telefono', $persona->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('celular')); ?>

                    <?php echo e(Form::text('celular', $persona->celular, ['class' => 'form-control' . ($errors->has('celular') ? ' is-invalid' : ''), 'required' => ''])); ?>

                    <?php echo $errors->first('celular', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Correo electrónico')); ?>

                    <?php echo e(Form::email('email', $persona->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'required' => ''])); ?>

                    <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Fecha nacimiento')); ?>

                    <?php echo e(Form::date('fecnacimiento', $persona->fecnacimiento, ['class' => 'form-control' . ($errors->has('fecnacimiento') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('fecnacimiento', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <?php echo e(Form::label('ocupación')); ?>

                    <?php echo e(Form::text('ocupacion', $persona->ocupacion, ['class' => 'form-control' . ($errors->has('ocupacion') ? ' is-invalid' : ''), 'placeholder' => ''])); ?>

                    <?php echo $errors->first('ocupacion', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
        </div>
        <h5>Datos complementarios</h5>
        <hr>
        <div class="row form-group">
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <label class="form-label">
                        Fecha de Ingreso
                    </label>
                    <?php echo e(Form::date('fecingreso', !is_null($asociado->fecingreso) ? $asociado->fecingreso : date("Y-m-d"), ['class' => 'form-control' . ($errors->has('fecingreso') ? ' is-invalid' : ''), 'placeholder' => 'Fecingreso'])); ?>

                    <?php echo $errors->first('fecingreso', '<div class="invalid-feedback">:message</div>'); ?>

                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="form-group">
                    <?php echo e(Form::label('Grado')); ?>

                    <?php echo e(Form::select('grado_id', $grados, !is_null($asociado->grado_id) ? $asociado->grado_id : null,['class'=>'form-select'])); ?>

                </div>
            </div>
            
        </div>


        <div class="form-group d-none">
            <?php echo e(Form::label('persona_id')); ?>

            <?php echo e(Form::text('persona_id', $asociado->persona_id, ['class' => 'form-control' . ($errors->has('persona_id') ? ' is-invalid' : ''), 'placeholder' => 'Persona Id'])); ?>

            <?php echo $errors->first('persona_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group d-none">
            <?php echo e(Form::label('user_id')); ?>

            <?php echo e(Form::text('user_id', $asociado->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Estado')); ?>

            <?php echo e(Form::select('estado_id', $estados, !is_null($asociado->estado_id) ? $asociado->estado_id : null,['class'=>'form-select'])); ?>

            <?php echo $errors->first('estado_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\team\resources\views/asociado/form.blade.php ENDPATH**/ ?>