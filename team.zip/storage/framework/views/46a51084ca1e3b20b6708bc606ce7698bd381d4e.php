<?php $__env->startSection('template_title'); ?>
    Update Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="">
            <div class="col-md-12">

                <?php if ($__env->exists('partials.errors')) echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card card-default">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>EDITAR ROL</strong>
                            </span>
                            
                            <div class="float-right">
                                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary btn-sm float-right"
                                    data-placement="left">
                                    <i class="far fa-arrow-alt-circle-left"></i> Volver</a>
                            </div>
                            

                        </div>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>" role="form"
                            enctype="multipart/form-data">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo csrf_field(); ?>

                            <div class="box box-info padding-1">
                                <div class="box-body">

                                    <div class="form-group">
                                        <?php echo e(Form::label('Nombre')); ?>

                                        <?php echo e(Form::text('name', $role->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese el nombre del rol'])); ?>

                                        <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

                                    </div>




                                    <h5 class="mt-2">Listado de permisos</h5>

                                    <?php
                                        $grupo = '';
                                        $indice = 0;
                                    ?>
        <div class="row">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($grupo != $permission->grupo): ?>
                                                <?php
                                                    $grupo = $permission->grupo;
                                                ?>  
                                                <?php if($indice > 0): ?>
        </tbody>
                                                    </table>
                                                </div>                                            
                                                <?php endif; ?>                                          
                                                <div class="col-12 col-md-4">
                                                    <table class="table table-sm table-bordered">
                                                        <thead>
                                                            <tr class="table-warning">
                                                                <th>
                                                                    <strong><?php echo e($permission->grupo); ?></strong>
                                                                    
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <label>
                                                                        <?php echo Form::checkbox(
                                                                            'permissions[]',
                                                                            $permission->id,
                                                                            in_array($permission->id, $rolePermissions) ? true : false,
                                                                            ['class' => 'mr-1'],
                                                                        ); ?>

                                                                        <?php echo e($permission->description); ?>

                                                                    </label>
                                                                </td>
                                                            </tr>
                                            <?php else: ?>
                                                        <tr>
                                                                <td>
                                                                    <label>
                                                                        <?php echo Form::checkbox(
                                                                            'permissions[]',
                                                                            $permission->id,
                                                                            in_array($permission->id, $rolePermissions) ? true : false,
                                                                            ['class' => 'mr-1'],
                                                                        ); ?>

                                                                        <?php echo e($permission->description); ?>

                                                                    </label>
                                                                </td>
                                                            </tr>                                            
                                            <?php endif; ?>
                                            <?php
                                                $indice++;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                    </div>



                                </div>
                                <div class="box-footer mt20">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\devconta\resources\views/role/edit.blade.php ENDPATH**/ ?>