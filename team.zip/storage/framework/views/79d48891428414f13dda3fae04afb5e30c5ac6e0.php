<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('nombre')); ?>

            <?php echo e(Form::text('nombre', $grado->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('descripción')); ?>

            <?php echo e(Form::text('descripcion', $grado->descripcion, ['class' => 'form-control' . ($errors->has('descripcion') ? ' is-invalid' : ''), 'placeholder' => 'Descripcion'])); ?>

            <?php echo $errors->first('descripcion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Pago único')); ?>

            <?php echo e(Form::text('coste', $grado->coste, ['class' => 'form-control' . ($errors->has('coste') ? ' is-invalid' : ''), 'placeholder' => 'Pago único'])); ?>

            <?php echo $errors->first('coste', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    
</div><?php /**PATH C:\xampp\htdocs\team\resources\views/grado/form.blade.php ENDPATH**/ ?>