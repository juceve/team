<?php $__env->startSection('content'); ?>
    <div class="mb-md-5 mt-md-4 pb-5">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <h3 class="fw-bold mb-2 text-uppercase"> <span class="text-primary">INICIO</span> <span
                    class="text-success">DE</span> <span class="text-danger">SESIÓN</span></h3>
            <p class="text-white-50 mb-5">Ingrese sus credenciales por favor!</p>

            <div class="form-outline form-white mb-4">
                <label class="form-label" for="email">Email</label>
                <input type="email" name="email" id="email"
                    class="form-control form-control-lg bg-dark text-white-50 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus style="border-color: white" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-outline form-white mb-4">
                <label class="form-label" for="password">Contraseña</label>
                <input type="password" id="password" name="password"
                    class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-dark text-white-50" required
                    autocomplete="current-password" style="border-color: white" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="row mb-3">
                <div class="col-md-6 ">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                            <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label" for="remember">
                            <?php echo e(__('Recordarme')); ?>

                        </label>
                    </div>
                </div>
            </div>
            <div class="row mb-0">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-outline-warning btn-lg px-5">
                        <?php echo e(__('Ingresar')); ?>

                    </button>
                    <br>
                    <?php if(Route::has('password.request')): ?>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Olvidó su contraseña?')); ?>

                        </a>
                    <?php endif; ?>
<br>
                    <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-link">Registrar nuevo usuario</a>
                        <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\project2\resources\views/auth/login.blade.php ENDPATH**/ ?>