<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Razón social')); ?>

            <?php echo e(Form::text('razonsocial', $cliente->razonsocial, ['class' => 'form-control' . ($errors->has('razonsocial') ? ' is-invalid' : ''), 'autofocus' => ''])); ?>

            <?php echo $errors->first('razonsocial', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('NIT')); ?>

            <?php echo e(Form::text('nit', $cliente->nit, ['class' => 'form-control' . ($errors->has('nit') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('nit', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <div class="form-group<?php echo e($errors->has('departamento') ? ' has-error' : ''); ?>">
            <?php echo Form::label('Departamento'); ?>

            <?php echo Form::select('departamento', ["" => "Seleccione un departamento", "Santa Cruz" => "Santa Cruz", "La Paz" => "La Paz", "Cochabamba" => "Cochabamba", "Chuquisaca" => "Chuquisaca", "Tarija" => "Tarija", "Beni" => "Beni", "Pando" => "Pando", "Potosi" => "Potosi", "Oruro" => "Oruro"], $cliente->departamento, ['class' => 'form-control' . ($errors->has('departamento') ? ' is-invalid' : '')]); ?>

            <small class="text-danger"><?php echo e($errors->first('departamento')); ?></small>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('ciudad')); ?>

            <?php echo e(Form::text('ciudad', $cliente->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('dirección')); ?>

            <?php echo e(Form::text('direccion', $cliente->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('teléfono')); ?>

            <?php echo e(Form::text('telefono', $cliente->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('actividad económica')); ?>

            <?php echo e(Form::text('actividad', $cliente->actividad, ['class' => 'form-control' . ($errors->has('actividad') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('actividad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('responsable')); ?>

            <?php echo e(Form::text('responsable', $cliente->responsable, ['class' => 'form-control' . ($errors->has('responsable') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('responsable', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Cédula del Responsable')); ?>

            <?php echo e(Form::text('nrocedularesp', $cliente->nrocedularesp, ['class' => 'form-control' . ($errors->has('nrocedularesp') ? ' is-invalid' : '')])); ?>

            <?php echo $errors->first('nrocedularesp', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <?php
            $dnone = '';       
            if (is_null($client_id))
            {$dnone = 'd-none';} 
        ?>
        <div class="form-group d-none">
            <?php echo e(Form::label('sucursal')); ?>

            <?php if(!is_null($client_id)): ?>
                <?php echo e(Form::text('sucursal', $cliente->sucursal ? $cliente->sucursal : $nrosucursal, ['class' => 'form-control' . ($errors->has('sucursal') ? ' is-invalid' : ''), 'readonly' => 'readonly'])); ?>

            <?php else: ?>
                <?php echo e(Form::text('sucursal', $cliente->sucursal ? $cliente->sucursal : '0', ['class' => 'form-control' . ($errors->has('sucursal') ? ' is-invalid' : '')])); ?>

            <?php endif; ?>
           
            <?php echo $errors->first('sucursal', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group <?php echo e($dnone); ?>">
            <?php echo e(Form::label('casamatriz')); ?>

            <?php if(!is_null($client_id)): ?>
                <?php echo e(Form::hidden('casamatriz', $client->id ? $client->id : '0', ['class' => 'form-control' . ($errors->has('casamatriz') ? ' is-invalid' : '')])); ?>

                <?php echo e(Form::text('casaMatrizRazonSocial', $client->razonsocial ? $client->razonsocial : '0', ['class' => 'form-control' . ($errors->has('casamatriz') ? ' is-invalid' : ''), 'readonly' => 'readonly'])); ?>

            <?php else: ?>
                <?php echo e(Form::text('casamatriz', $cliente->casamatriz ? $cliente->casamatriz : '0', ['class' => 'form-control' . ($errors->has('casamatriz') ? ' is-invalid' : '')])); ?>

            <?php endif; ?>
            
            <?php echo $errors->first('casamatriz', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\devconta\resources\views/cliente/form.blade.php ENDPATH**/ ?>