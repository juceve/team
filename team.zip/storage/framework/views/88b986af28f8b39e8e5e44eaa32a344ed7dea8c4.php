<?php $__env->startSection('title-page'); ?>
    Asociados |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
    ASOCIADOS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Listado de asociados')); ?>

                            </span>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asociados.create')): ?>
                                <div class="float-right">
                                    <a href="<?php echo e(route('asociados.create')); ?>" class="btn btn-primary btn-sm float-right"
                                        data-placement="left">
                                        <i class="fas fa-user-plus"></i> <?php echo e(__('Nuevo')); ?>

                                    </a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover dataTable">
                                <thead class="thead">
                                    <tr class="table-info">
                                        <th>NRO.</th>

                                        <th>ASOCIADO</th>
                                        <th>GRADO</th>
                                        <th>ESTADO APORTES</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $asociados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asociado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>

                                            <td><?php echo e($asociado->persona->apellidos . ' ' . $asociado->persona->nombres); ?></td>
                                            <td><?php echo e($asociado->grado->nombre); ?></td>
                                            <td><?php echo e($asociado->estado->nombre); ?></td>

                                            <td align="center">

                                                <form class="deleted"
                                                    action="<?php echo e(route('asociados.destroy', $asociado->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="btn-group">
                                                        <button type="button" class="btn btn-secondary dropdown-toggle"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            Opciones
                                                        </button>
                                                        <div class="dropdown-menu">
                                                            <a class="dropdown-item "
                                                                href="<?php echo e(route('asociados.show', $asociado->id)); ?>"><i
                                                                    class="fa fa-fw fa-eye text-black-50"></i> Ver info</a>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asociados.edit')): ?>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(route('asociados.edit', $asociado->id)); ?>"><i
                                                                        class="fa fa-fw fa-edit text-black-50"></i> Editar</a>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vinculos.manage')): ?>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(route('vinculos', $asociado->id)); ?>">
                                                                    <i class="fas fa-sitemap text-black-50"></i> Vinculos</a>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(route('users.edit', $asociado->user_id)); ?>">
                                                                    <i class="fas fa-user-circle text-black-50"></i> Usuario</a>
                                                            <?php endif; ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asociados.destroy')): ?>
                                                                <button type="submit" class="dropdown-item" id="deleted"
                                                                    title="Eliminar">
                                                                    <i class="fa fa-fw fa-trash text-black-50"></i>
                                                                    Eliminar</button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
    <script>
        $('.deleted').submit(function(e) {
            e.preventDefault();
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
            })

            swalWithBootstrapButtons.fire({
                title: 'Eliminar Registro!',
                text: "Esta seguro de realizar la operación?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Si, elimínalo!',
                cancelButtonText: 'No, cancelar!',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                } else if (
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Operación cancelada',
                        'No se modificó ningún registro',
                        'error'
                    )
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\team\resources\views/asociado/index.blade.php ENDPATH**/ ?>