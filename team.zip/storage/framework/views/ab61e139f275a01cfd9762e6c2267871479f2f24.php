<?php $__env->startSection('title-page'); ?>
Listado de Clientes  |  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-content'); ?>
CLIENTES REGISTRADOS    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <strong>Listado de Clientes</strong>
                            </span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.create')): ?>
                                <div class="float-right">
                                <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary btn-sm float-right"
                                    data-placement="left">
                                    <i class="fas fa-plus-circle"></i>
                                    <?php echo e(__('Crear nuevo')); ?>

                                </a>
                            </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>

                    <div class="card-body container-fluid">
                        <div class="table-responsive" style="min-height: 450px">
                            <table class="table table-striped table-hover dataTable">
                                <thead class="thead">
                                    <tr class="table-primary text-center">
                                        <th>NRO.</th>

                                        <th>RAZON SOCIAL</th>
                                        <th>NIT</th>
                                        <th>DEPARTAMENTO</th>

                                        <th width='100'></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e(++$i); ?></td>

                                            <td><?php echo e($cliente->razonsocial); ?></td>
                                            <td><?php echo e($cliente->nit); ?></td>
                                            <td><?php echo e($cliente->departamento); ?></td>

                                            <td class="text-center">
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-info">
                                                        Acciones
                                                    </button>
                                                    <button type="button"
                                                        class="
                                                        btn btn-info
                                                        dropdown-toggle dropdown-toggle-split
                                                      "
                                                        data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <span class="sr-only">Toggle Dropdown</span>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>"
                                                            method="POST" class="eliminar">
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('clientes.show', $cliente->id)); ?>"
                                                                title="Ver info">Ver info</a>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.edit')): ?>
                                                                <a class="dropdown-item"
                                                                href="<?php echo e(route('clientes.edit', $cliente->id)); ?>"
                                                                title="Editar datos">Editar datos</a>
                                                            <?php endif; ?>
                                                            
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.create')): ?>
                                                                <a class="dropdown-item"
                                                                href="<?php echo e(route('createsuc', $cliente->id)); ?>"
                                                                title="Crear sucursal">Crear sucursal</a>
                                                            <?php endif; ?>
                                                            
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.destroy')): ?>
                                                                <button type="submit" class="dropdown-item">
                                                                    Eliminar
                                                                </button>
                                                            <?php endif; ?>
                                                            
                                                        </form>
                                                    </div>
                                                </div>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php if(session('success') != ''): ?>
        {
        <script>
            Swal.fire(
                'Excelente!',
                '<?php echo e(session('success')); ?>',
                'success'
            );
        </script>
        }
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            $('.eliminar').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: 'Esta seguro de eliminar el registro?',
                    text: "El registro eliminado no se podrá recuperar",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Si, eliminar!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.submit();
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\devconta\resources\views/cliente/index.blade.php ENDPATH**/ ?>