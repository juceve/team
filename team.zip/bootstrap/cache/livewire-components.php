<?php return array (
  'uploadpics' => 'App\\Http\\Livewire\\Uploadpics',
  'vinculos' => 'App\\Http\\Livewire\\Vinculos',
);